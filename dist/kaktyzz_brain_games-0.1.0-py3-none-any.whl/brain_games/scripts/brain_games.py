
#!/home/yakov/project/brain_games/scripts python3
from brain_games.cli import run


def main():
    print("Welcome to the brain Games!")


if __name__ == '__main__':
    main()

run()
