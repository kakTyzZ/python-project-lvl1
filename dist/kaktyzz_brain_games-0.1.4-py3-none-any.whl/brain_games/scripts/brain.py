

def welcome():
    return "Welcome to the brain Games!"

if __name__ == "__main__":
    welcome()


